<?php

namespace App\Models;

use CodeIgniter\Model;

class TestModel extends Model
{
    protected $table = 'tests';
    protected $primaryKey = 'test_id';

    protected $allowedFields = [
        'test_id',
        'test_name',
        'test_category_id',
        'procedure',
        'action',
        'pricing'
    ];

    protected $useTimestamps = true; 

    protected $validationRules = [
        'test_id' => 'required|integer',
        'test_name' => 'permit_empty|string|max_length[255]',
        'test_category_id' => 'permit_empty|integer',
        'procedure' => 'permit_empty|string',
        'action' => 'permit_empty|string',
        'pricing' => 'permit_empty|decimal'
    ];

    protected $validationMessages = [
        'test_id' => [
            'required' => 'Test ID is required.',
            'integer' => 'Test ID must be an integer.'
        ],
        'test_name' => [
            'string' => 'Test Name must be a string.',
            'max_length' => 'Test Name cannot exceed 255 characters.'
        ],
        'test_category_id' => [
            'integer' => 'Test Category ID must be an integer.'
        ],
        'procedure' => [
            'string' => 'Procedure must be a string.'
        ],
        'action' => [
            'string' => 'Action must be a string.'
        ],
        'pricing' => [
            'decimal' => 'Pricing must be a decimal number.'
        ]
    ];
}
