<?php

namespace App\Models;

use CodeIgniter\Model;

class LoginModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';

    protected $allowedFields = ['email', 'password'];
    protected $useTimestamps = true;

    protected $validationRules = [
        'email' => 'required|valid_email',
        'password' => 'required'
    ];
}
