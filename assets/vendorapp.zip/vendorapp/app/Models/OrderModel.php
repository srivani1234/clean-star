<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = 'orders';
    protected $primaryKey = 'orderId';

    protected $allowedFields = [
        'sampleId',
        'name',
        'user_id',
        'deadLine',
        'totalPrice',
        'status',
        'tests',
        'qr_code',
    ];

    protected $useTimestamps = true; 

    protected $validationRules = [
        'sampleId' => 'required|alpha_numeric',
        'name' => 'required|string',
        'user_id' => 'required|string',
        'deadLine' => 'required|valid_date',
        'totalPrice' => 'required|decimal',
        'status' => 'required|string',
        'tests' => 'required|string',
    ];

    protected $validationMessages = [
        'sampleId' => [
            'required' => 'Sample ID is required.',
            'alpha_numeric' => 'Sample ID must be alphanumeric.'
        ],
        'name' => [
            'required' => 'Name is required.',
            'string' => 'Name must be a string.'
        ],
        'user_id' => [
            'required' => 'User ID is required.',
            'string' => 'User ID must be an integer.'
        ],
        'deadLine' => [
            'required' => 'Deadline is required.',
            'valid_date' => 'Deadline must be a valid date.'
        ],
        'totalPrice' => [
            'required' => 'Total Price is required.',
            'decimal' => 'Total Price must be a decimal number.'
        ],
        'status' => [
            'required' => 'Status is required.',
            'string' => 'Status must be a string.'
        ],
        'tests' => [
            'required' => 'Tests is required.',
            'string' => 'Tests must be a string.'
        ]
    ];
}
