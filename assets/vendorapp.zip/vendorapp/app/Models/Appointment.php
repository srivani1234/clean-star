<?php
namespace App\Models;

use CodeIgniter\Model;

class Appointment extends Model {
 
    protected $table = 'appointments';

    protected $primaryKey = 'id';
    
	// get all fields of table
    protected $allowedFields = ['id','fullname','email','service','message','created_by'];
	
	protected $validationRules = [];
	protected $validationMessages = [];
	protected $skipValidation = false;
	
}