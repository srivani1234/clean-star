<?php

namespace App\Models;

use CodeIgniter\Model;



class TestCategoryModel extends Model
{
    protected $table = 'test_categories'; // Ensure this is the correct table name
    protected $primaryKey = 'id'; // Replace with your primary key field

    protected $allowedFields = ['name']; // Replace with the fields you want to insert/update
}
