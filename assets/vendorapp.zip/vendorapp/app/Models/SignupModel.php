<?php

namespace App\Models;

use CodeIgniter\Model;

class SignupModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';

    protected $allowedFields = ['email', 'password', 'mobile'];
    protected $useTimestamps = true;

    protected $validationRules = [
        'email' => 'required|valid_email|is_unique[users.email]',
        'password' => 'required|min_length[6]',
        'mobile' => 'required|numeric'
    ];

    protected $validationMessages = [
        'email' => [
            'is_unique' => 'This email is already registered'
        ],
        'password' => [
            'min_length' => 'Password must be at least 6 characters long'
        ],
        'mobile' => [
            'numeric' => 'Mobile number must be numeric'
        ]
    ];
}
