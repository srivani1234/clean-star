<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = 'orders'; // Adjust to your orders table name
    protected $primaryKey = 'id';

    protected $allowedFields = ['order_id', 'sample_id']; // Add other fields as necessary
    protected $useTimestamps = true; // If you have timestamp fields

    // Optionally, add validation rules
    protected $validationRules = [
        'order_id' => 'required',
        'sample_id' => 'required'
    ];
}
