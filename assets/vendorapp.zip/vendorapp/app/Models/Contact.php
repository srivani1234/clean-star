<?php
namespace App\Models;

use CodeIgniter\Model;

class Contact extends Model {
 
    protected $table = 'contacts';

    protected $primaryKey = 'id';
    
	// get all fields of table
    protected $allowedFields = ['id','fullname','email','phone','subject','message','created_at'];
	
	protected $validationRules = [];
	protected $validationMessages = [];
	protected $skipValidation = false;
	
}