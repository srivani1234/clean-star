<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes = Services::routes();

$routes->setAutoRoute(true);    

// $routes->get('/', 'Home::index');
// $routes->post('/post', 'Home::post',['namespace'=>'App\Controllers']);

// $routes->post('get/profile', 'Auth::getProfile',['namespace'=>'App\Controllers']);
// $routes->post('login', 'Auth::login');
// $routes->post('signup', 'Auth::signup');
// $routes->post('change/password', 'Auth::changePassword');

// $routes->post('createorder', 'Auth2::createOrder',['namespace'=>'App\Controllers']);

// $routes->get('orders', 'Order::showAll',['namespace'=>'App\Controllers']);
// $routes->get('orders/(:num)', 'Order::show/$1',['namespace'=>'App\Controllers']);
// $routes->post('showorders', 'Order::showOrders',['namespace'=>'App\Controllers']);

// $routes->get('getTests', 'Order::getTests');