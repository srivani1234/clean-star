<?php

namespace App\Controllers;

use App\Models\LoginModel;
use App\Models\OrderModel;
use App\Models\SignupModel;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;
use SimpleSoftwareIO\QrCode\Generator;

class Orders extends BaseController
{
    public function index(): string
    {
        return "Success";
    }

    

    public function createorder(): ResponseInterface
    {
        $orderModel = new OrderModel();

        $orderData = $this->request->getJSON(true);

        $qrcode = new Generator;
        $qrCodes = [];
       

        if (!is_array($orderData) || !isset($orderData['sampleId']) || !isset($orderData['userId']) || !isset($orderData['name'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'All fields are required'
            ]);
        }

        $data = [
            'sampleId' => $orderData['sampleId'],
            'user_id' => $orderData['userId'],
            'name' => $orderData['name'],
            'deadLine' => $orderData['deadLine'],
            'totalPrice' => $orderData['totalPrice'],
            'status' => $orderData['status'],
            'tests' => $orderData['tests']
        ];

        $order=$orderModel->insert($data);

        if ($order) {
            $qrCodeValue = $qrcode->size(120)->generate('http://localhost/newworkflow/lqms/orders?order_id=' . $order);
            $data2 = ['qr_code' => $qrCodeValue];
            $order2 = $orderModel->update($order, $data2);

            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Order created successfully',
                'qr_code' => $qrCodeValue,
                'order_id'=>$order,
            ]);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to create order'])->setStatusCode(500);
        }
    }

    public function showall(): ResponseInterface
    {
        $orderModel = new OrderModel();
        $orders = $orderModel->findAll();
        return $this->response->setJSON($orders);
    }


}
