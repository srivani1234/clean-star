<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use App\Models\TestModel;
use App\Models\TestCategoryModel;

class Test extends BaseController
{
    public function index(): string
    {
        return "Success";
    }

    public function showall(): ResponseInterface
    {
        $testModel = new TestModel();
        $tests = $testModel->findAll(); 
        return $this->response->setJSON($tests); 
    }
    public function showallcategories(): ResponseInterface
    {
        $testModel = new TestCategoryModel();
        $test_categories = $testModel->findAll(); 
        return $this->response->setJSON($test_categories); 
    }

    public function addtest(): ResponseInterface
    {
        $testModel = new TestModel(); 

        $testData = $this->request->getJSON(true);

        if (!is_array($testData) || !isset($testData['test_category_id']) || !isset($testData['test_name']) || !isset($testData['pricing'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'All fields are required'
            ]);
        }

        $data = [
            'test_name' => $testData['test_name'],
            'test_category_id' => $testData['test_category_id'],
            'procedure' => isset($testData['procedure']),
            'action' => isset($testData['action']) ,
            'pricing' => isset($testData['pricing']),
        ];

        if ($testModel->save($data)) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Test added successfully.'
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to add test.'
            ])->setStatusCode(500);
        }
    }

    public function gettests(): ResponseInterface
    {
        $TestModel = new TestModel();

        $TestData = $this->request->getJSON(true);
       

        if (!is_array($TestData) || !isset($TestData['testCategoryId'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'All fields are required'
            ]);
        }

        $data = [
            'test_category_id' => $TestData['testCategoryId'],
        ];

        if ($TestModel->save($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => '  suuccess']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed '])->setStatusCode(500);
        }
    }
}
