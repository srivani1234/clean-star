<?Php
namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\TestModel;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;


class Order extends BaseController{
    public function __construct()
    {
        date_default_timezone_set('Asia/Kolkata');
    }

    public function index(): string
    {
        return "Success";
    }
    public function options()
    {
        header('Access-Control-Allow-Origin: *'); // Replace with your desired domain if you want to restrict access
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');   


        exit;
    }
    

    public function createOrder(): ResponseInterface
    {
        $orderModel = new OrderModel();

        $orderData = $this->request->getJSON(true);
       

        if (!is_array($orderData) || !isset($orderData['sampleId']) || !isset($orderData['userId']) || !isset($orderData['name'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'All fields are required'
            ]);
        }

        $data = [
            'sampleId' => $orderData['sampleId'],
            'user_id' => $orderData['userId'],
            'name' => $orderData['name'],
            'deadLine' => $orderData['deadLine'],
            'totalPrice' => $orderData['totalPrice'],
            'status' => $orderData['status'],
            'tests' => $orderData['tests'],
        ];

        if ($orderModel->save($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Order created successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to create order'])->setStatusCode(500);
        }
    }

    public function showAll(): ResponseInterface
    {
        $orderModel = new OrderModel();
        $orders = $orderModel->findAll();
        return $this->response->setJSON($orders);
    }

    public function getTests():ResponseInterface
    {
        {
            $testModel = new TestModel();
            
            $tests = $testModel->findAll();
    
            if ($tests) {
                return $this->response->setJSON($tests);
            } else {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'No tests found'
                ])->setStatusCode(404);
            }
        }
    }

    public function show($id=null): ResponseInterface
    {
        $orderModel = new OrderModel();
        $order = $orderModel->find($id);

        if ($order) {
            return $this->response->setJSON($order);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Order not found'])->setStatusCode(404);
        }
    }

    public function showorders(): ResponseInterface
    {
        $json = $this->request->getJSON(true); 

        if (!isset($json['user_id'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User ID is required'
            ])->setStatusCode(400);
        }

        $userId = $json['user_id'];

        $orderModel = new OrderModel();
        $orders = $orderModel->where('user_id', $userId)->findAll();

        if ($orders) {
            return $this->response->setJSON($orders);
        } else {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'No orders found for this user'
            ])->setStatusCode(404);
        }
    }
}
