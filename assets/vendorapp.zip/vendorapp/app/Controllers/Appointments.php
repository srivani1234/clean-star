<?php

namespace App\Controllers;

use App\Models\Appointment;
use CodeIgniter\HTTP\ResponseInterface;
use SimpleSoftwareIO\QrCode\Generator;

class Appointments extends BaseController
{
    public function index(): string
    {
        return "Success";
    }

    

    public function create(): ResponseInterface
    {
        $AppointmentModel = new Appointment();

        $AppointmentData = $this->request->getJSON(true);
        $data = [
            'fullname' => $AppointmentData['fullname'],
            'email' => $AppointmentData['email'],
            'service' => $AppointmentData['service'],
            'message' => $AppointmentData['message']
            
        ];

        $appointment=$AppointmentModel->insert($data);

        if ($appointment) {
           
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Appointment created successfully',
                'appointment_id'=>$appointment,
            ]);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to  create appointment'])->setStatusCode(500);
        }
    }

    public function showall(): ResponseInterface
    {
        $AppointmentModel = new Appointment();
        $appointments = $AppointmentModel->findAll();
        return $this->response->setJSON($appointments);
    }


    public function delete($id = null)
    {
        // Load the ContactModel
        $model = new Appointment();

        // Check if the contact exists
        $Appointment = $model->find($id);

        if (!$Appointment) {
            return $this->response->setJSON([
                'status' => 'not found',
                'message' => 'Appointment not found',
                'appointment_id'=>$Appointment,
            ])->setStatusCode(404);
        }

        // Delete the contact
        if ($model->delete($id)) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Appointment deleted successfully',
                'appointment_id'=>$Appointment,
            ])->setStatusCode(200);
        } else {

            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to delete  Appointment',
                'appointment_id'=>$Appointment,
            ])->setStatusCode(500);
            
        }
    }


}
