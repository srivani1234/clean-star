<?php

namespace App\Controllers;

use App\Models\UsersModel;
use CodeIgniter\HTTP\ResponseInterface;
use Firebase\JWT\JWT;



class Auth extends BaseController
{
    public function index(): string
    {
        return "Success";
    }

    

    public function login(): ResponseInterface
    {
        $json = $this->request->getJSON(true);
        
        if (!is_array($json) || !isset($json['username']) || !isset($json['password'])) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Username and password are required'
            ]);
        }
    
        $username = $json['username'];
        $password = $json['password'];
    
        $loginModel = new UsersModel();
        $user = $loginModel->where('username', $username)->first();
        
        if ($user && password_verify($password, $user['password'])) {
            $key = "prbhatech";
            $payload = [
                'iss' => "lqms.prabhatech.com",
                'aud' => "lqms.prabhatech.com",
                'iat' => time(),
                'nbf' => time(),
                'exp' => time() + 3600,
                'data' => [
                    'username' => $user['username'],
                ]
            ];
    
            $algorithm = 'HS256'; 
    
            try {
                $jwt = JWT::encode($payload, $key, $algorithm);
            } catch (Exception $e) {
                return $this->response->setStatusCode(500)->setJSON([
                    'status' => 'error',
                    'message' => 'Failed to generate token'
                ]);
            }
            $UsersModel = new UsersModel();
            $userid=$UsersModel->where('username', $username)->first();
            return $this->response->setStatusCode(200)->setJSON([
                'status' => 'success',
                'message' => 'Login successful',
                'token' => $jwt,
                'userid'=>$userid['user_id'],
            ]);
        } else {
            return $this->response->setStatusCode(401)->setJSON([
                'status' => 'error',
                'message' => 'Invalid username or password'
            ]);
        }
    }
    
    public function signup(): ResponseInterface
{
    $UsersModel = new UsersModel();
    $json = $this->request->getJSON(true); 

    // Validate input
    if (!is_array($json) || !isset($json['email']) || !isset($json['password']) || !isset($json['mobile']) || !isset($json['username'])) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Email, password, mobile, and username are required'
        ]);
    }

    // Extract data from the request
    $email = $json['email'];
    $password = $json['password'];
    $mobile = $json['mobile'];
    $first_name = $json['first_name'] ?? '';
    $last_name = $json['last_name'] ?? '';
    $username = $json['username'];

    // Prepare user data
    $data = [
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'user_type' => 'customer',
        'username' => $username,
        'password' => password_hash($password, PASSWORD_BCRYPT),
        'contact_number' => $mobile,
        'country' => 0,
        'user_role_id' => 0,
        'address_1' => '',
        'address_2' => '',
        'city' => '',
        'profile_photo' => '',
        'state' => '',
        'zipcode' => '',
        'gender' => '',
        'company_name' => '',
        'trading_name' => '',
        'registration_no' => '',
        'government_tax' => '',
        'company_type_id' => 0,
        'last_login_date' => '0',
        'last_logout_date' => '0',
        'last_login_ip' => '0',
        'is_logged_in' => '0',
        'is_active' => 1,
        'company_id' => '',
        'created_at' => date('Y-m-d H:i:s')
    ];

    // Validate data
    if (!$UsersModel->validate($data)) {
        $errors = $UsersModel->errors();
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Validation failed: ' . implode(', ', $errors)
        ]);
    }

    // Save user data
    if ($UsersModel->save($data)) {
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Signup successful'
        ]);
    } else {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Failed to save user data'
        ]);
    }
}


    public function changePassword(): ResponseInterface
    {
        $json = $this->request->getJSON();

        // Retrieve data from JSON body
        $email = $json->email ?? null;
        $oldPassword = $json->old_password ?? null;
        $newPassword = $json->new_password ?? null;

        // Validate input
        if (empty($email) || empty($oldPassword) || empty($newPassword)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Email, old password, and new password are required'
            ]);
        }

        $userModel = new UserModel();
        $user = $userModel->where('email', $email)->first();

        if (!$user) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found'
            ])->setStatusCode(404);
        }

        // Verify old password
        if (!password_verify($oldPassword, $user['password'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Old password is incorrect'
            ]);
        }

        // Validate new password (e.g., length check, complexity check)
        if (strlen($newPassword) < 6) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'New password must be at least 6 characters long'
            ]);
        }

        // Hash the new password
        $hashedNewPassword = password_hash($newPassword, PASSWORD_BCRYPT);

        // Update the password
        if ($userModel->update($user['id'], ['password' => $hashedNewPassword])) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Password changed successfully'
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to change password'
            ]);
        }
    }


    public function getProfile(): ResponseInterface
    {
        $json = $this->request->getJSON();
        $email = $json->email ?? null;

        // Validate input
        if (empty($email)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Email is required'
            ]);
        }

        $userModel = new UserModel();
        $user = $userModel->where('email', $email)->first();

        if (!$user) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found'
            ])->setStatusCode(404);
        }

        // Exclude sensitive data like password from the response
        unset($user['password']);

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $user
        ]);
    }

   

}
