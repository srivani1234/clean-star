<?php

namespace App\Controllers;

use App\Models\Contact;
use CodeIgniter\HTTP\ResponseInterface;
use SimpleSoftwareIO\QrCode\Generator;

class Contacts extends BaseController
{
 

    public function create(): ResponseInterface
    {
        $contactsModel = new Contact();

        $contactsData = $this->request->getJSON(true);
        $data = [
            'fullname' => $contactsData['fullname'],
            'email' => $contactsData['email'],
            'phone' => $contactsData['phone'],
            'subject' => $contactsData['subject'],
            'message' => $contactsData['message']
            
        ];

        $contact=$contactsModel->insert($data);

        if ($contact) {
           
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Contact created successfully',
                'contact_id'=>$contact,
            ]);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to  create contact'])->setStatusCode(500);
        }
    }

    public function showall(): ResponseInterface
    {
        $ContactModel = new Contact();
        $contacts = $ContactModel->findAll();
        return $this->response->setJSON($contacts);
    }

    public function delete($id = null)
    {
        // Load the ContactModel
        $model = new Contact();

        // Check if the contact exists
        $Contact = $model->find($id);

        if (!$Contact) {
            return $this->response->setJSON([
                'status' => 'not found',
                'message' => 'Contact not found',
                'Contact_id'=>$Contact,
            ])->setStatusCode(404);
        }

        // Delete the contact
        if ($model->delete($id)) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Contact deleted successfully',
                'Contact_id'=>$Contact,
            ])->setStatusCode(200);
        } else {

            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to delete Contact',
                'Contact_id'=>$Contact,
            ])->setStatusCode(500);
            
        }
    }


}
